import glfw
import os
from OpenGL.GL import *
from OpenGL.GLU import *
from time import sleep
import numpy as np
from OpenGL.arrays import vbo
import ctypes


Azimuth_ang = np.radians(10)
Elevation_ang = np.radians(10)
gcamDist=5
target=np.array([0,0,0])
fovy=90
PSens=.005
delta=2*gcamDist*np.tan(np.radians(fovy/2)) * PSens
RSens=.005
RSensVertical=.005
up=[0,1,0]
dirr=-1
realdirr=-1
anim_mode=False
i=0
column=0

def createVertexArraySeparate():
    varr = np.array([
            (-0.5773502691896258 , 0.5773502691896258 , 0.5773502691896258 ),
            (-1,1,1),
            ( 0.8164965809277261 , 0.4082482904638631, 0.4082482904638631 ),
            (1,1,1),
            ( 0.4082482904638631 , -0.4082482904638631 , 0.8164965809277261 ),
            (1,-1,1),
            ( -0.4082482904638631 , -0.8164965809277261 , 0.4082482904638631 ),
            (-1,-1,1),
            ( -0.4082482904638631 , 0.4082482904638631 , -0.8164965809277261),
            (-1,1,0),
            ( 0.4082482904638631 , 0.8164965809277261 , -0.4082482904638631 ),
            (1,1,0),
            ( 0.5773502691896258 , -0.5773502691896258 , -0.5773502691896258),
            (1,-1,0),
            ( -0.8164965809277261 , -0.4082482904638631 , -0.4082482904638631 ),
            (-1,-1,0),
            ],'float32')
    iarr = np.array([
            (0,2,1),
            (0,3,2),
            (4,5,6),
            (4,6,7),
            (0,1,5),
            (0,5,4),
            (3,6,2),
            (3,7,6),
            (1,2,6),
            (1,6,5),
            (0,7,3),
            (0,4,7),
            ])
    return varr, iarr

def drawCube_glDrawElements():
    global gVertexArraySeparate, gIndexArray
    varr = gVertexArraySeparate
    iarr = gIndexArray
    glEnableClientState(GL_VERTEX_ARRAY)
    glEnableClientState(GL_NORMAL_ARRAY)
    glNormalPointer(GL_FLOAT, 6*varr.itemsize, varr)
    glVertexPointer(3, GL_FLOAT, 6*varr.itemsize, ctypes.c_void_p(varr.ctypes.data + 3*varr.itemsize))
    glDrawElements(GL_TRIANGLES, iarr.size, GL_UNSIGNED_INT, iarr)
    
def orbit(dx, dy):
    global Azimuth_ang, Elevation_ang, up, dirr, realdirr

    Azimuth_ang=Azimuth_ang+realdirr*dx*RSens
    Elevation_ang=Elevation_ang+dy*RSensVertical

    modular=(Elevation_ang/(np.pi/2))%4
    modular=int(modular)
    if modular==1 or modular==2:
        up=[0,-1,0]
        dirr=1
    else:
        up=[0,1,0]
        dirr=-1

def panning(dx, dy):
    global target, delta, Azimuth_ang, Elevation_ang, gcamDist, up
    w=np.array([gcamDist*np.cos(Elevation_ang)*np.sin(Azimuth_ang), 
    gcamDist*np.sin(Elevation_ang),
    gcamDist*np.cos(Elevation_ang)*np.cos(Azimuth_ang)])
    w=normalize(w)

    up=np.array(up)
    u=np.cross(up, w)
    u=normalize(u)

    v=np.cross(w,u)
    v=normalize(v)
    eyeCoord=u,v
    target=target+delta*-dx*eyeCoord[0] + delta*dy*eyeCoord[1]

def zomming(dt):
    global gcamDist, delta
    gcamDist=gcamDist*(1+dt)
    
    if gcamDist<=.2:
        gcamDist=.2

    delta=2*gcamDist*np.tan(np.radians(fovy/2)) * PSens

def render(t):
    global fovy, i, strt, column
    glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT)
    glEnable(GL_DEPTH_TEST)
    glPolygonMode(GL_FRONT_AND_BACK, GL_FILL)

    glMatrixMode(GL_PROJECTION)
    glLoadIdentity()
    gluPerspective(fovy, 1, 0.1 , 3000)

    glMatrixMode(GL_MODELVIEW)
    glLoadIdentity()

    eye=np.array([gcamDist*np.cos(Elevation_ang)*np.sin(Azimuth_ang), 
    gcamDist*np.sin(Elevation_ang),
    gcamDist*np.cos(Elevation_ang)*np.cos(Azimuth_ang)])
    eye[0]=eye[0]+target[0]
    eye[1]=eye[1]+target[1]
    eye[2]=eye[2]+target[2]

    gluLookAt(eye[0], eye[1], eye[2], target[0], target[1], target[2], up[0], up[1], up[2])

    drawFrame()

    glEnable(GL_LIGHTING)  
    glEnable(GL_LIGHT0)
    glEnable(GL_LIGHT1)

    lightPos = (-5., 5., 5., 1.)
    lightPos1 = (5., 5., 5., 1.)
    glLightfv(GL_LIGHT0, GL_POSITION, lightPos)
    glLightfv(GL_LIGHT1, GL_POSITION, lightPos1)

    ambientLightColor = (.1, .1, .1, .8)
    diffuseLightColor = (.7, .6, .5, .8)
    specularLightColor = (1., 1., 1., .8)
    glLightfv(GL_LIGHT0, GL_AMBIENT, ambientLightColor)
    glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuseLightColor)
    glLightfv(GL_LIGHT0, GL_SPECULAR, specularLightColor)

    ambientLightColor1 = (.1, .1, .1, .8)
    diffuseLightColor1 = (.3, 1., .5, .8)
    specularLightColor1 = (1., 1., 1., .8)
    glLightfv(GL_LIGHT1, GL_AMBIENT, ambientLightColor1)
    glLightfv(GL_LIGHT1, GL_DIFFUSE, diffuseLightColor1)
    glLightfv(GL_LIGHT1, GL_SPECULAR, specularLightColor1)

    diffuseObjectColor = (1., 1., 1., 1.)
    specularObjectColor = (1., 1., 1., 1.)
    glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, diffuseObjectColor)

    glColor3ub(0, 0, 255)
    if strt!=None:
        column=0
        DrawBVH(strt, i)
    glDisable(GL_LIGHTING)

def drawFrame() :
    glBegin(GL_LINES)
    glColor3ub(255,0, 0)
    glVertex3fv(np.array([0.,0.,0.]))
    glVertex3fv(np.array([5.,0.,0.]))
    glColor3ub(0,255,0)
    glVertex3fv(np.array([0.,0.,0.]))
    glVertex3fv(np.array([0.,5.,0.]))
    glColor3ub(0,0,255)
    glVertex3fv(np.array([0.,0.,0.]))
    glVertex3fv(np.array([0.,0.,5.]))
    glEnd()
    glColor3ub(255,255,255)
    for x in range(-100,100):
        glBegin(GL_LINES)
        glVertex3fv(np.array([x,0.,100]))
        glVertex3fv(np.array([x,0,-100]))
        glEnd()
    for z in range(-100,100):
        glBegin(GL_LINES)
        glVertex3fv(np.array([100.,0.,z]))
        glVertex3fv(np.array([-100.,0.,z]))
        glEnd()

prev=0
def onMouseButton(window, x, y):
    global prev, dirr, realdirr

    if glfw.get_mouse_button(window, glfw.MOUSE_BUTTON_LEFT) == glfw.PRESS:
        orbit(x-prev[0],y-prev[1])
        prev=x,y
        return

    elif glfw.get_mouse_button(window, glfw.MOUSE_BUTTON_RIGHT) == glfw.PRESS:
        panning(x-prev[0], y-prev[1])
        prev=x,y
        return
   
    realdirr=dirr
    prev=x,y

def onScrollEvent(window, xoffset, yoffset):
    zomming(-yoffset*0.2)

def normalize(v):
    norm = np.linalg.norm(v)
    if norm == 0: 
       return v
    return v / norm

strt = None
motn = {
    "Frames": 0,
    "Frame Time": 0,
    "anim" : []
}

def init():
    global strt, motn, anim_mode, i, column
    strt = None
    motn = {
        "Frames": 0,
        "Frame Time": 0,
        "anim" : []
    }

    anim_mode=False
    i=0

    column=0

def read_bvh_file(path):
    global strt, motn

    stk=[]

    STATES=["EMptimeY", "HIERARCHY", "MOTION"]
    state=STATES[0]

    format_strt={
        "sort" : "",
        "name" : "",
        "OFFSET" : None,
        "CHANNELS" : None,
        "CHILDS" : None
    }

    joints=[]

    with open(path[0], "r") as f:
        for data in f:
            if not data:
                break
            data = data.split()
            if data == []: 
                continue
 
            if data[0]==STATES[1]:
                state=STATES[1]

            elif data[0]==STATES[2]:
                state=STATES[2]
            
            elif state==STATES[1]:
                if data[0] in ["ROOT", "JOINT", "End"]:
                    top=format_strt.copy()
                    stk.append(top)

                    top["sort"]=data[0]
                    top["name"]=data[1]

                    if data[0]!="End":
                        joints.append(data[1])
                    
                elif data[0]=="OFFSET":
                    top=stk[-1]
                    top["OFFSET"]=np.array(data[1:],"float32")

                elif data[0]=="CHANNELS":
                    top=stk[-1]
                    top["CHANNELS"]=data[2:]

                elif data[0]=="}":
                    if len(stk)==0:
                        print ("parsing error")

                    elif len(stk)==1:
                        strt=stk[-1]
                        stk.pop()
                    
                    else:
                        top=stk.pop()

                        if stk[-1]["CHILDS"]==None:
                            stk[-1]["CHILDS"]=[]

                        stk[-1]["CHILDS"].append(top)

                        if stk[-1]["name"]=="Head":
                            head_offset=top["OFFSET"]
                    
            elif state==STATES[2]:

                if data[0]=="Frames:":
                    motn["Frames"]=int(data[1])
                
                elif data[0]=="Frame" and data[1]=="Time:":
                    motn["Frame Time"]=float(data[2])

                else:
                    motn["anim"].append(data)

    motn["anim"]=np.array(motn["anim"], "float32")

    print ("1. File name:", path[0])
    print ("2. Number of frames:", motn["Frames"])
    print ("3. FPS:", int(1/motn["Frame Time"]))
    print ("4. Number of joints:", len(joints))
    print ("5. List of all joint names:")

    for el in joints:
        print (el,end=', ')
    print ("")

def DrawBVH(src, frame_num):
    global motn, strt, anim_mode, column

    if src==None:
        return 

    glPushMatrix()
     
    if src["sort"]=="ROOT": 
        glTranslatef(src["OFFSET"][0], src["OFFSET"][1], src["OFFSET"][2])

    if anim_mode and motn["Frames"]>0:
        if src["CHANNELS"]!=None:
            for deg in src["CHANNELS"]:
                deg=deg.upper()
                if deg=="XPOSITION":
                    glTranslatef(motn["anim"][frame_num][column], 0, 0)
                elif deg=="YPOSITION":
                    glTranslatef(0, motn["anim"][frame_num][column], 0)
                elif deg=="ZPOSITION":
                    glTranslatef(0, 0, motn["anim"][frame_num][column])
                elif deg=="XROTATION":
                    glRotatef(motn["anim"][frame_num][column], 1, 0, 0)
                elif deg=="YROTATION":
                    glRotatef(motn["anim"][frame_num][column], 0, 1, 0)
                elif deg=="ZROTATION":
                    glRotatef(motn["anim"][frame_num][column], 0, 0, 1)
            
                column+=1 

    if src["CHILDS"]!=None:
        for el in src["CHILDS"]: 
            glPushMatrix()
            glColor3ub(255,255,0)
            eye = np.array((0,0,0))
            up = np.array((0,1,0))
            M = np.identity(4)
            w = np.array(3)
            w = (eye-el["OFFSET"])/np.sqrt(np.dot(eye-el["OFFSET"],eye-el["OFFSET"]))
            u = np.array(3)
            u = np.cross(up,w)/np.sqrt(np.dot(np.cross(up,w),np.cross(up,w)))
            v = np.array(3)
            v = np.cross(w,u)
            M[:3,0] = u
            M[:3,1] = v
            M[:3,2] = w
            M[:3,3] = eye
            glPushMatrix()
            glMultMatrixf(M.T)
            n = np.sqrt(np.dot(eye-el["OFFSET"],eye-el["OFFSET"]))
            glScalef(1,1,-n)
            drawCube_glDrawElements()
            glPopMatrix()
            glTranslatef(el["OFFSET"][0], el["OFFSET"][1], el["OFFSET"][2])
            DrawBVH(el, frame_num)

            glPopMatrix()
            
    glPopMatrix()   

def drop_callback(window, path):
    init()
    read_bvh_file(path)

def key_callback(window, key, scancode, action, mods):
    global anim_mode, i

    if action==glfw.PRESS or action==glfw.REPEAT:
        if key==glfw.KEY_SPACE:
            if anim_mode:
                anim_mode=False
                i=0
            else:
                anim_mode=True
gVertexArraySeparate = None
gIndexArray = None
def main():
    global prev, rigid, i, motn, anim_mode, gVertexArraySeparate, gIndexArray
    if not glfw.init():
        return
    window = glfw.create_window(640,640,'2014004193-class3', None,None)
    if not window:
        glfw.terminate()
        return
    glfw.make_context_current(window)
    glfw.set_cursor_pos_callback(window, onMouseButton)
    glfw.set_scroll_callback(window, onScrollEvent)
    glfw.set_drop_callback(window,drop_callback)
    glfw.set_key_callback(window, key_callback)
    prev=glfw.get_cursor_pos(window)
    gVertexArraySeparate, gIndexArray = createVertexArraySeparate()
    ptime=0.0
    while not glfw.window_should_close(window):
        t=glfw.get_time()
        glfw.poll_events()
        render(t)

        if anim_mode and motn["Frames"]>0:

            i=(i+1)%motn["Frames"]     

            remain_t = t-ptime

            if remain_t<motn["Frame Time"]:
                sleep(motn["Frame Time"]-remain_t)

        ptime=t
        glfw.swap_buffers(window)

    glfw.terminate()


if __name__ == "__main__":
    main()
