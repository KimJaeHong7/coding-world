import numpy as np
import glfw
from OpenGL.GLU import *
from OpenGL.GL import *
global fovy
global flag
global horizontalAngle
global verticalAngle
global up
global target
prev = 0
target = np.zeros(3)
up = 1
verticalAngle = 0.
horizontalAngle = 0.
flag = 0
fovy=30
cnt=0
count=0
def drawSphere(numLats=12, numLongs=12):

    for i in range(0, numLats + 1):
        lat0 = np.pi * (-0.5 + float(float(i - 1) / float(numLats)))
        z0 = np.sin(lat0)
        zr0 = np.cos(lat0)

        lat1 = np.pi * (-0.5 + float(float(i) / float(numLats)))
        z1 = np.sin(lat1)
        zr1 = np.cos(lat1)

        glBegin(GL_QUAD_STRIP)

        for j in range(0, numLongs + 1):
            lng = 2 * np.pi * float(float(j - 1) / float(numLongs))
            x = np.cos(lng)
            y = np.sin(lng)
            glVertex3f(x * zr0, y * zr0, z0)
            glVertex3f(x * zr1, y * zr1, z1)
        glEnd()

def drawObject(count,cnt):
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
    glEnable(GL_DEPTH_TEST)
    glPolygonMode(GL_FRONT_AND_BACK, GL_LINE)

    glPushMatrix()
    glScalef(8,8,8)
    glPushMatrix()
    glTranslatef(0, .1, 0)
    glRotatef(np.sin(cnt) * 10, 0, 1, 0)
    
    glPushMatrix()
    glScalef(.2, .28, .2)
    glColor3ub(255, 0, 0)
    drawCube()
    glPopMatrix()
    glPopMatrix()

    #head
    glPushMatrix()
    glTranslatef(0, .4, 0)
    glRotatef(np.sin(cnt)*3, 0, 1, 0)

    glPushMatrix()
    glScalef(.2, .2, .2)
    glColor3ub(0, 255, 255)
    drawSphere()
    glPopMatrix()
    glPopMatrix()
    #left arm1
    glPushMatrix()
    glTranslatef(0, .17, -.15)
    glRotatef(np.sin(cnt) * 30, 0, 0, 1)

    glPushMatrix()
    glScalef(.08, .16, .08)
    glColor3ub(0, 255, 255)
    drawCube()
    glPopMatrix()

    #left arm2
    glPushMatrix()
    glTranslatef(.1, -.1, 0)
    glScalef(.2, .08, .08)
    glColor3ub(255, 255, 0)
    drawCube()
    glPopMatrix()

    #left hand
    glPushMatrix()
    glTranslatef(.25, -.1, 0)
    glRotatef(np.sin(cnt)*60, 0, 0, 1)

    glScalef(.08, .08, .08)
    glColor3ub(255, 0, 255)
    drawSphere()

    glPopMatrix()
    glPopMatrix()

    #right arm1
    glPushMatrix()
    glTranslatef(0, .17, .15)
    glRotatef(np.sin(cnt) * (-30), 0, 0, 1)

    glPushMatrix()
    glScalef(.08, .16, .08)
    glColor3ub(0, 255, 255)
    drawCube()
    glPopMatrix()
    #right arm2
    glPushMatrix()
    glTranslatef(.1, -.1, 0)

    glScalef(.2, .08, .08)
    glColor3ub(255, 255, 0)
    drawCube()

    glPopMatrix()

    #right hand
    
    glPushMatrix()
    glTranslatef(.25, -.1, 0)
    glRotatef(np.sin(cnt) * 60, 0, 0, 1)

    glScalef(.08, .08, .08)
    glColor3ub(255, 0, 255)
    drawSphere()
    glPopMatrix()
    glPopMatrix()

    #left leg1
    glPushMatrix()
    glTranslatef(0, -.15, -.07)
    glRotatef(np.sin(cnt) * (-30), 0, 0, 1)

    glPushMatrix()
    glScalef(.09, .2, .09)
    glColor3ub(0, 255, 255)
    drawCube()
    glPopMatrix()
    #left leg2
    glPushMatrix()
    glTranslatef(0, -.2, 0)
    glRotatef(120 + (count % 60), 0, 0.0, 1)

    glScalef(.09, .2, .09)
    glColor3ub(255, 255, 0)
    drawCube()
    glPopMatrix()

    # left foot
    glPushMatrix()
    glTranslatef(0, -.3, 0)
    glRotatef(130 + (count % 60), 0, 0.0, 1)

    glScalef(.15, .05, .1)
    glColor3ub(255, 0, 255)
    drawCube()
    glPopMatrix()
    glPopMatrix()


    #right leg1
    glPushMatrix()
    glTranslatef(0, -.15, .07)
    glRotatef(np.sin(cnt) * (30), 0, 0, 1)

    glPushMatrix()
    glScalef(.09, .2, .09)
    glColor3ub(0, 255, 255)
    drawCube()
    glPopMatrix()
    #right leg2
    glPushMatrix()
    glTranslatef(0, -.2, 0)
    glRotatef(120 + (count % 60), 0, 0, 1)

    glScalef(.09, .2, .09)
    glColor3ub(255, 255, 0)
    drawCube()
    glPopMatrix()

    #right foot
    glPushMatrix()
    glTranslatef(0, -.3, 0)
    glRotatef(130 + (count % 60), 0, 0, 1)

    glScalef(.15, .05, .1)
    glColor3ub(255, 0, 255)
    drawCube()
    glPopMatrix()
    glPopMatrix()
    glPopMatrix()
def drawCube():
    glBegin(GL_QUADS)
    
    glVertex3f(0.5,0.5,-0.5)
    glVertex3f(-0.5,0.5,-0.5)
    glVertex3f(-0.5,0.5,0.5)
    glVertex3f(0.5,0.5,0.5)
    
    glVertex3f(0.5,-0.5, 0.5)
    glVertex3f(-0.5,-0.5, 0.5)
    glVertex3f(-0.5,-0.5,-0.5)
    glVertex3f( 0.5,-0.5,-0.5)
    
    glVertex3f( 0.5, 0.5, 0.5)
    glVertex3f(-0.5, 0.5, 0.5)
    glVertex3f(-0.5,-0.5, 0.5)
    glVertex3f( 0.5,-0.5, 0.5)
    
    glVertex3f(0.5,-0.5,-0.5)
    glVertex3f(-0.5, -0.5,-0.5)
    glVertex3f( -0.5, 0.5,-0.5)
    glVertex3f(0.5, 0.5, -0.5)
    
    glVertex3f(-0.5, 0.5,0.5)
    glVertex3f(-0.5,0.5,-0.5)
    glVertex3f(-0.5,-0.5, -0.5)
    glVertex3f( -0.5, -0.5,0.5)

    glVertex3f( 0.5, 0.5,-0.5)
    glVertex3f( 0.5, 0.5, 0.5)
    glVertex3f( 0.5,-0.5, 0.5)
    glVertex3f( 0.5,-0.5,-0.5)
    
    glEnd()
def drawFrame() :
    glBegin(GL_LINES)
    glColor3ub(255,0, 0)
    glVertex3fv(np.array([0.,0.,0.]))
    glVertex3fv(np.array([5.,0.,0.]))
    glColor3ub(0,255,0)
    glVertex3fv(np.array([0.,0.,0.]))
    glVertex3fv(np.array([0.,5.,0.]))
    glColor3ub(0,0,255)
    glVertex3fv(np.array([0.,0.,0.]))
    glVertex3fv(np.array([0.,0.,5.]))
    glEnd()
    glColor3ub(255,255,255)
    for x in range(-5,6):
        glBegin(GL_LINES)
        glVertex3fv(np.array([x,0.,5]))
        glVertex3fv(np.array([x,0,-5]))
        glEnd()
    for z in range(-5,6):
        glBegin(GL_LINES)
        glVertex3fv(np.array([5.,0.,z]))
        glVertex3fv(np.array([-5.,0.,z]))
        glEnd()
def render(count,cnt):
    global horizontalAngle, verticalAngle, up, fovy, target
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
    glEnable(GL_DEPTH_TEST)
    glLoadIdentity()
    glOrtho(-5,5,-5,5,-5,5)
    gluPerspective(fovy,1,-10,10)
    gluLookAt(10*np.sin(np.radians(horizontalAngle))*(np.cos(np.radians(verticalAngle)))+target[0],
              10*np.sin(np.radians(verticalAngle))+target[1],
              10*np.cos(np.radians(verticalAngle))*np.cos(np.radians(horizontalAngle))+target[2],
              target[0],target[1],target[2],0,up,0)
    drawObject(count,cnt)
    drawFrame()
    
def button_callback(window,button,action,mod):
    global gCamAng
    global flag
    if button==glfw.MOUSE_BUTTON_LEFT:
        if action==glfw.PRESS:
            flag = 1
        elif action==glfw.RELEASE:
            flag = 0
    elif button == glfw.MOUSE_BUTTON_RIGHT:
        if action == glfw.PRESS:
            flag = 2
        elif action == glfw.RELEASE:
            flag = 0
       
def cursor_callback(window, xpos, ypos):
    global flag, horizontalAngle, verticalAngle, up, prev, target
    if flag ==1:
        verticalAngle =(verticalAngle+(prev[1]-ypos)/5)
        if np.cos(np.radians(verticalAngle))<0:
            up = -1
        elif np.cos(np.radians(verticalAngle))>=0:
            up = 1
        if up == -1:
            horizontalAngle =(horizontalAngle-(prev[0]-xpos)/5)
        elif up == 1:
            horizontalAngle = (horizontalAngle+(prev[0]-xpos)/5)
    elif flag == 2:
        a=10*np.sin(np.radians(horizontalAngle))*(np.cos(np.radians(verticalAngle)))
        b=10*np.sin(np.radians(verticalAngle))
        c=10*np.cos(np.radians(verticalAngle))*np.cos(np.radians(horizontalAngle))
        w = np.array(3)
        w = np.array([a,b,c])
        w = w/np.sqrt(np.dot(w,w))
        upv = np.array([0,up,0])
        u = np.cross(upv,w)
        u = u/np.sqrt(np.dot(u,u))
        v = np.cross(w,u)
        v = v/np.sqrt(np.dot(v,v))
        target = target + (prev[0]-xpos)*u*0.05 + (ypos-prev[1])*v*0.05
    prev=xpos, ypos
def scroll_callback(window, xoffset, yoffset):
    global fovy
    if fovy>=1 and fovy<=90:
        fovy-=yoffset
    elif fovy<1:
        fovy = 1
    elif fovy>90:
        fovy=90
    
def main():
    global cnt, count
    if not glfw.init():
        return
    window = glfw.create_window(640,640,"2015004439-assignment",None,None)
    if not window:
        glfw.terminate()
        return
    glfw.set_mouse_button_callback(window,button_callback)
    glfw.set_scroll_callback(window,scroll_callback)
    glfw.make_context_current(window)
    glfw.set_cursor_pos_callback(window, cursor_callback)
    prev = glfw.get_cursor_pos(window)
    while not glfw.window_should_close(window):
        glfw.poll_events()
        render(count,cnt)

        glfw.swap_buffers(window)

        cnt +=0.1
        count +=1
    glfw.terminate()
    

if __name__ == "__main__":
    main()
    
