import glfw
from OpenGL.GL import *
from OpenGL.GLU import *
import numpy as np
from OpenGL.arrays import vbo
import ctypes
import math

gShader = True
prev = 0
target = np.zeros(3)
up = 1
verticalAngle = 0.
horizontalAngle = 0.
flag = 0
fovy=15
gPong = False
gVertexArray = []
def drawUnitCube_glDrawArray():
    global gVertexArray
    varr_ = np.array(gVertexArray)
    glEnableClientState(GL_VERTEX_ARRAY)
    glEnableClientState(GL_NORMAL_ARRAY)
    glNormalPointer(GL_FLOAT, 6 * varr_.itemsize, varr_)
    glVertexPointer(3, GL_FLOAT, 6 * varr_.itemsize, ctypes.c_void_p(varr_.ctypes.data + 3 * varr_.itemsize))
    glDrawArrays(GL_TRIANGLES, 0, int(varr_.size / 6))


def drawFrame():
    glBegin(GL_LINES)
    glColor3ub(255, 0, 0)
    glVertex3fv(np.array([0., 0., 0.]))
    glVertex3fv(np.array([1., 0., 0.]))
    glColor3ub(0, 255, 0)
    glVertex3fv(np.array([0., 0., 0.]))
    glVertex3fv(np.array([0., 1., 0.]))
    glColor3ub(0, 0, 255)
    glVertex3fv(np.array([0., 0., 0]))
    glVertex3fv(np.array([0., 0., 1.]))
    glEnd()
    glColor3ub(255,255,255)
    for x in range(-5,6):
        glBegin(GL_LINES)
        glVertex3fv(np.array([x,0.,5]))
        glVertex3fv(np.array([x,0,-5]))
        glEnd()
    for z in range(-5,6):
        glBegin(GL_LINES)
        glVertex3fv(np.array([5.,0.,z]))
        glVertex3fv(np.array([-5.,0.,z]))
        glEnd()

def button_callback(window,button,action,mod):
    global flag
    if button==glfw.MOUSE_BUTTON_LEFT:
        if action==glfw.PRESS:
            flag = 1
        elif action==glfw.RELEASE:
            flag = 0
    elif button == glfw.MOUSE_BUTTON_RIGHT:
        if action == glfw.PRESS:
            flag = 2
        elif action == glfw.RELEASE:
            flag = 0

def key_callback(window, key, scancode, action, mods):
    global gShader, gPong, varr1, gVertexArray, varr
    if action == glfw.PRESS or action == glfw.REPEAT:
        if key == glfw.KEY_Z:
            gShader = not gShader
        elif key == glfw.KEY_S:
            gPong = not gPong
            if gPong == True:
                gVertexArray = varr1
            elif gPong == False:
                gVertexArray = varr
def cursor_callback(window, xpos, ypos):
    global flag, horizontalAngle, verticalAngle, up, prev, target
    if flag ==1:
        verticalAngle =(verticalAngle+(prev[1]-ypos)/5)
        if np.cos(np.radians(verticalAngle))<0:
            up = -1
        elif np.cos(np.radians(verticalAngle))>=0:
            up = 1
        if up == -1:
            horizontalAngle =(horizontalAngle-(prev[0]-xpos)/5)
        elif up == 1:
            horizontalAngle = (horizontalAngle+(prev[0]-xpos)/5)
    elif flag == 2:
        a=10*np.sin(np.radians(horizontalAngle))*(np.cos(np.radians(verticalAngle)))
        b=10*np.sin(np.radians(verticalAngle))
        c=10*np.cos(np.radians(verticalAngle))*np.cos(np.radians(horizontalAngle))
        w = np.array(3)
        w = np.array([a,b,c])
        w = w/np.sqrt(np.dot(w,w))
        upv = np.array([0,up,0])
        u = np.cross(upv,w)
        u = u/np.sqrt(np.dot(u,u))
        v = np.cross(w,u)
        v = v/np.sqrt(np.dot(v,v))
        target = target + (prev[0]-xpos)*u*0.05 + (ypos-prev[1])*v*0.05
    prev=xpos, ypos

def scroll_callback(window, xoffset, yoffset):
    global fovy
    if fovy>=1 and fovy<=90:
        fovy-=yoffset
    elif fovy<1:
        fovy = 1
    elif fovy>90:
        fovy=90
        
def render():
    global gShader, up, fovy, target
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)

    glEnable(GL_DEPTH_TEST)

    if gShader:
        glPolygonMode(GL_FRONT_AND_BACK, GL_FILL)
    else:
        glPolygonMode(GL_FRONT_AND_BACK, GL_LINE)

    glMatrixMode(GL_PROJECTION)
    glLoadIdentity()
    glOrtho(-5,5,-5,5,-5,5)
    gluPerspective(fovy, 1, -10, 10)

    glMatrixMode(GL_MODELVIEW)

    glLoadIdentity()
    gluLookAt(8*np.sin(np.radians(horizontalAngle))*(np.cos(np.radians(verticalAngle)))+target[0],
              8*np.sin(np.radians(verticalAngle))+target[1],
              8*np.cos(np.radians(verticalAngle))*np.cos(np.radians(horizontalAngle))+target[2],
              target[0],target[1],target[2],0,up,0)

    drawFrame()

    glEnable(GL_LIGHTING)  
    glEnable(GL_LIGHT0)
    glEnable(GL_LIGHT1)

    lightPos = (-5., 5., 5., 1.)
    lightPos1 = (5., 5., 5., 1.)
    glLightfv(GL_LIGHT0, GL_POSITION, lightPos)
    glLightfv(GL_LIGHT1, GL_POSITION, lightPos1)

    ambientLightColor = (.1, .1, .1, .8)
    diffuseLightColor = (.7, .6, .5, .8)
    specularLightColor = (1., 1., 1., .8)
    glLightfv(GL_LIGHT0, GL_AMBIENT, ambientLightColor)
    glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuseLightColor)
    glLightfv(GL_LIGHT0, GL_SPECULAR, specularLightColor)

    ambientLightColor1 = (.1, .1, .1, .8)
    diffuseLightColor1 = (.3, 1., .5, .8)
    specularLightColor1 = (1., 1., 1., .8)
    glLightfv(GL_LIGHT1, GL_AMBIENT, ambientLightColor1)
    glLightfv(GL_LIGHT1, GL_DIFFUSE, diffuseLightColor1)
    glLightfv(GL_LIGHT1, GL_SPECULAR, specularLightColor1)

    diffuseObjectColor = (1., 1., 1., 1.)
    specularObjectColor = (1., 1., 1., 1.)
    glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, diffuseObjectColor)

    glColor3ub(0, 0, 255)

    drawUnitCube_glDrawArray()

    glDisable(GL_LIGHTING)


def drop_callback(window, paths):

    global gVertexArray, gPong, varr1, varr

    vertex = []
    n_vector = []
    face = []
    varr = []
    varr1 = []
    varr3 = []
    f3_iarr = []
    f4_iarr = []
    f3_cnt = 0
    f4_cnt = 0
    fm_cnt = 0
    cnt = 0
    index1 = 0
    index2 = 0
    index3 = 0
    t_vertex = []
    t_n_v = []
    n1 = 0
    n2 = 0
    n3 = 0
    n = 0
    cp = 0
    
    OBJ_file = open(" ".join(paths), 'r')

    for line in OBJ_file:
        if line[:2] == "v ":
            index1 = line.find(" ") + 1
            index2 = line.find(" ", index1 + 1)
            index3 = line.find(" ", index2 + 1)

            v = (float(line[index1:index2]), float(line[index2:index3]), float(line[index3:-1]))
            vertex.append(v)
        elif line[:2] == "vn":
            index1 = line.find(" ") + 1
            index2 = line.find(" ", index1 + 1)
            index3 = line.find(" ", index2 + 1)

            unit_v = (float(line[index1:index2]), float(line[index2:index3]), float(line[index3:-1]))
            n_vector.append(unit_v)

        elif line[:2] == "f ":
            l = line.split()
            tmp = np.array(l[1:])
            face_num = np.size(tmp)
            if face_num == 3:
                f3_cnt += 1
            elif face_num == 4:
                f4_cnt += 1
            elif face_num > 4:
                fm_cnt += 1
            ls = l[1].split('/')
            f_n_vertex = n_vector[int(ls[2]) - 1]
            f_v_vertex = vertex[int(ls[0]) - 1]
            varr.append(f_n_vertex)
            varr.append(f_v_vertex)
            ls = l[2].split('/')
            s_n_vertex = n_vector[int(ls[2]) - 1]
            s_v_vertex = vertex[int(ls[0]) - 1]
            varr.append(s_n_vertex)
            varr.append(s_v_vertex)
            i = 3
            if face_num == 3 :
                la = l[1].split('/')
                la1 = l[2].split('/')
                la2 = l[3].split('/')
                f3_iarr.append((float(la[0]),float(la1[0]),float(la2[0])))
            elif face_num == 4 :
                la = l[1].split('/')
                la1 = l[2].split('/')
                la2 = l[3].split('/')
                la3 = l[4].split('/')
                f4_iarr.append((float(la[0]),float(la1[0]),float(la2[0]),float(la3[0])))
            while face_num > 3:
                 ls = l[i].split('/')
                 t_n_vertex = n_vector[int(ls[2]) - 1]
                 t_v_vertex = vertex[int(ls[0]) - 1]
                 varr.append(t_n_vertex)
                 varr.append(t_v_vertex)
                 s_n_vertex=t_n_vertex
                 s_v_vertex=t_v_vertex
                 varr.append(f_n_vertex)
                 varr.append(f_v_vertex)
                 varr.append(s_n_vertex)
                 varr.append(s_v_vertex)
                 i+=1
                 face_num-=1
                    
            ls = l[i].split('/')
            t_n_vertex = n_vector[int(ls[2]) - 1]
            t_v_vertex = vertex[int(ls[0]) - 1]
            varr.append(t_n_vertex)
            varr.append(t_v_vertex)
    length = len(vertex)
    varr1 = np.empty(((f3_cnt+f4_cnt*2)*6,3),dtype = 'float32')
    varr = np.array(varr, dtype = 'float32')
    t_vertex = np.zeros((length,3), dtype = 'float32')
    for k in range(f3_cnt) :
        a = vertex[int(f3_iarr[k][0])-1][0]*-1
        b = vertex[int(f3_iarr[k][0])-1][1]*-1
        c = vertex[int(f3_iarr[k][0])-1][2]*-1
        t_n_v = (float(a),float(b),float(c))
        x = vertex[int(f3_iarr[k][1])-1][0] + t_n_v[0]
        y = vertex[int(f3_iarr[k][1])-1][1] + t_n_v[1]
        z = vertex[int(f3_iarr[k][1])-1][2] + t_n_v[2]
        n1 = (float(x),float(y),float(z))
        x1 = vertex[int(f3_iarr[k][2])-1][0] + t_n_v[0]
        y1 = vertex[int(f3_iarr[k][2])-1][1] + t_n_v[1]
        z1 = vertex[int(f3_iarr[k][2])-1][2] + t_n_v[2]
        n2 = (float(x1),float(y1),float(z1))
        n3 = np.cross(n1,n2)
        t_vertex[int(f3_iarr[k][0])-1] += n3
        t_vertex[int(f3_iarr[k][1])-1] += n3
        t_vertex[int(f3_iarr[k][2])-1] += n3
    for j in range(f4_cnt) :
        a = vertex[int(f4_iarr[j][0])-1][0]*-1
        b = vertex[int(f4_iarr[j][0])-1][1]*-1
        c = vertex[int(f4_iarr[j][0])-1][2]*-1
        t_n_v = (float(a),float(b),float(c))
        
        x = vertex[int(f4_iarr[j][1])-1][0] + t_n_v[0]
        y = vertex[int(f4_iarr[j][1])-1][1] + t_n_v[1]
        z = vertex[int(f4_iarr[j][1])-1][2] + t_n_v[2]
        n1 = (float(x),float(y),float(z))
        
        x1 = vertex[int(f4_iarr[j][2])-1][0] + t_n_v[0]
        y1 = vertex[int(f4_iarr[j][2])-1][1] + t_n_v[1]
        z1 = vertex[int(f4_iarr[j][2])-1][2] + t_n_v[2]
        n2 = (float(x1),float(y1),float(z1))
        
        n3 = np.cross(n1,n2)
        t_vertex[int(f4_iarr[j][0])-1] += n3
        t_vertex[int(f4_iarr[j][1])-1] += n3
        t_vertex[int(f4_iarr[j][2])-1] += n3
        
        x = vertex[int(f4_iarr[j][2])-1][0] + t_n_v[0]
        y = vertex[int(f4_iarr[j][2])-1][1] + t_n_v[1]
        z = vertex[int(f4_iarr[j][2])-1][2] + t_n_v[2]
        n1 = (float(x),float(y),float(z))
        
        x1 = vertex[int(f4_iarr[j][3])-1][0] + t_n_v[0]
        y1 = vertex[int(f4_iarr[j][3])-1][1] + t_n_v[1]
        z1 = vertex[int(f4_iarr[j][3])-1][2] + t_n_v[2]
        n2 = (float(x1),float(y1),float(z1))
        
        n3 = np.cross(n1,n2)
        t_vertex[int(f4_iarr[j][0])-1] += n3
        t_vertex[int(f4_iarr[j][2])-1] += n3
        t_vertex[int(f4_iarr[j][3])-1] += n3
        
    for q in range(f3_cnt) :
        t_v = int(f3_iarr[q][0])
        t_v1 = int(f3_iarr[q][1])
        t_v2 = int(f3_iarr[q][2])
        if np.sqrt(np.dot(t_vertex[t_v - 1],t_vertex[t_v - 1])) == 0:
            temp = np.array([0.,0.,0.])
        else:
            temp = t_vertex[t_v - 1]/np.sqrt(np.dot(t_vertex[t_v - 1],t_vertex[t_v - 1]))
        if np.sqrt(np.dot(t_vertex[t_v1 - 1],t_vertex[t_v1 - 1])) == 0:
            temp1 = np.array([0.,0.,0.])
        else:
            temp1 = t_vertex[t_v1 - 1]/np.sqrt(np.dot(t_vertex[t_v1 - 1],t_vertex[t_v1 - 1]))
        if np.sqrt(np.dot(t_vertex[t_v2 - 1],t_vertex[t_v2 - 1])) == 0:
            temp2 = np.array([0.,0.,0.])
        else:
            temp2 = t_vertex[t_v2 - 1]/np.sqrt(np.dot(t_vertex[t_v2 - 1],t_vertex[t_v2 - 1]))
        varr1[cp] = temp
        varr1[cp+1] = vertex[t_v-1]
        varr1[cp+2] = temp1
        varr1[cp+3] = vertex[t_v1-1]
        varr1[cp+4] = temp2
        varr1[cp+5] = vertex[t_v2-1]
        cp += 6
    for p in range(f4_cnt) :
        t_v = int(f4_iarr[p][0])
        t_v1 = int(f4_iarr[p][1])
        t_v2 = int(f4_iarr[p][2])
        t_v3 = int(f4_iarr[p][3])
        if np.sqrt(np.dot(t_vertex[t_v - 1],t_vertex[t_v - 1])) == 0:
            temp = np.array([0.,0.,0.])
        else:
            temp = t_vertex[t_v-1]/np.sqrt(np.dot(t_vertex[t_v - 1],t_vertex[t_v - 1]))
        if np.sqrt(np.dot(t_vertex[t_v1 - 1],t_vertex[t_v1 - 1])) == 0:
            temp1 = np.array([0.,0.,0.])
        else:
            temp1 = t_vertex[t_v1 - 1]/np.sqrt(np.dot(t_vertex[t_v1 - 1],t_vertex[t_v1 - 1]))
        if np.sqrt(np.dot(t_vertex[t_v2 - 1],t_vertex[t_v2 - 1])) == 0:
            temp2 = np.array([0.,0.,0.])
        else:
            temp2 = t_vertex[t_v2 - 1]/np.sqrt(np.dot(t_vertex[t_v2 - 1],t_vertex[t_v2 - 1]))
        if np.sqrt(np.dot(t_vertex[t_v3 - 1],t_vertex[t_v3 - 1])) == 0:
            temp3 = np.array([0.,0.,0.])
        else:
            temp3 = t_vertex[t_v3 - 1]/np.sqrt(np.dot(t_vertex[t_v3 - 1],t_vertex[t_v3 - 1]))
        varr1[cp] = temp
        varr1[cp+1] = vertex[t_v-1]
        varr1[cp+2] = temp1
        varr1[cp+3] = vertex[t_v1-1]
        varr1[cp+4] = temp2
        varr1[cp+5] = vertex[t_v2-1]
        varr1[cp+6] = temp
        varr1[cp+7] = vertex[t_v-1]
        varr1[cp+8] = temp2
        varr1[cp+9] = vertex[t_v2-1]
        varr1[cp+10] = temp3
        varr1[cp+11] = vertex[t_v3-1]
                 
        cp += 12
    ft_cnt = f3_cnt + f4_cnt + fm_cnt
    print("File name : " + str(paths))
    print("Total number of faces : " + str(ft_cnt))
    print("Number of faces with 3 vertices : " + str(f3_cnt))
    print("Number of faces with 4 vertices : " + str(f4_cnt))
    print("Number of faces with more than 4 vertices : " + str(fm_cnt))
    gVertexArray = varr

def main():

    if not glfw.init():
        return

    window = glfw.create_window(900, 900, "2015004439", None, None)
    if not window:
        glfw.terminate()
        return

    glfw.make_context_current(window)
    glfw.set_key_callback(window, key_callback)
    glfw.swap_interval(1)
    glfw.set_drop_callback(window, drop_callback)
    glfw.set_scroll_callback(window,scroll_callback)
    glfw.set_cursor_pos_callback(window, cursor_callback)
    glfw.set_mouse_button_callback(window,button_callback)
    prev = glfw.get_cursor_pos(window)
    
    while not glfw.window_should_close(window):
        glfw.poll_events()
        render()
        glfw.swap_buffers(window)

    glfw.terminate()


if __name__ == "__main__":
    main()
