-- MySQL dump 10.16  Distrib 10.3.10-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: bank
-- ------------------------------------------------------
-- Server version	10.3.10-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `account`
--

DROP TABLE IF EXISTS `account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account` (
  `money` bigint(20) NOT NULL,
  `Makedate` date NOT NULL,
  `Accountnumber` char(10) NOT NULL,
  `Usr_ssn` char(9) NOT NULL,
  PRIMARY KEY (`Accountnumber`),
  KEY `Usr_ssn` (`Usr_ssn`),
  CONSTRAINT `account_ibfk_1` FOREIGN KEY (`Usr_ssn`) REFERENCES `user` (`Ssn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account`
--

LOCK TABLES `account` WRITE;
/*!40000 ALTER TABLE `account` DISABLE KEYS */;
INSERT INTO `account` VALUES (0,'2018-12-03','1616161616','131313131'),(0,'2018-12-03','3232323232','121212121'),(0,'2018-12-03','6666666666','970122333'),(12000,'2018-12-03','7777777777','940112999'),(68000,'2018-12-03','9999999999','951212123');
/*!40000 ALTER TABLE `account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `check_card`
--

DROP TABLE IF EXISTS `check_card`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `check_card` (
  `money` int(11) DEFAULT NULL,
  `validity` date NOT NULL,
  `Accountnumber` char(10) NOT NULL,
  `User_ssn` char(9) NOT NULL,
  `cardnumber` char(11) NOT NULL,
  PRIMARY KEY (`cardnumber`),
  KEY `Accountnumber` (`Accountnumber`),
  KEY `User_ssn` (`User_ssn`),
  CONSTRAINT `check_card_ibfk_1` FOREIGN KEY (`Accountnumber`) REFERENCES `account` (`Accountnumber`),
  CONSTRAINT `check_card_ibfk_2` FOREIGN KEY (`User_ssn`) REFERENCES `user` (`Ssn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `check_card`
--

LOCK TABLES `check_card` WRITE;
/*!40000 ALTER TABLE `check_card` DISABLE KEYS */;
INSERT INTO `check_card` VALUES (12000,'2023-12-03','7777777777','940112999','01024091033'),(0,'2023-12-03','3232323232','121212121','01033332222'),(68000,'2023-12-03','9999999999','951212123','01050428039');
/*!40000 ALTER TABLE `check_card` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `manager`
--

DROP TABLE IF EXISTS `manager`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `manager` (
  `Sex` varchar(3) DEFAULT NULL,
  `Salary` int(11) DEFAULT NULL,
  `Address` varchar(30) DEFAULT NULL,
  `BirthDate` date DEFAULT NULL,
  `Name` varchar(15) NOT NULL,
  `Ssn` varchar(9) NOT NULL,
  PRIMARY KEY (`Ssn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `manager`
--

LOCK TABLES `manager` WRITE;
/*!40000 ALTER TABLE `manager` DISABLE KEYS */;
INSERT INTO `manager` VALUES ('M',350,'교대역','1995-09-09','최홍규','950909'),('M',8000,'여수','1996-07-10','김재홍','960710'),('F',5000,'목포','1996-10-19','김형준','961019');
/*!40000 ALTER TABLE `manager` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `Sex` varchar(3) DEFAULT NULL,
  `Address` varchar(30) DEFAULT NULL,
  `Name` varchar(30) NOT NULL,
  `Birthdate` date DEFAULT NULL,
  `Account_count` int(11) DEFAULT NULL,
  `Withdrawal_Date` date DEFAULT NULL,
  `Withdrawal_money` int(11) DEFAULT NULL,
  `Send_Date` date DEFAULT NULL,
  `Send_money` int(11) DEFAULT NULL,
  `Send_who` varchar(30) DEFAULT NULL,
  `Ssn` char(9) NOT NULL,
  `Mgr_ssn` varchar(9) DEFAULT NULL,
  `Send_num` char(10) DEFAULT NULL,
  `Withdrawal_num` char(10) DEFAULT NULL,
  PRIMARY KEY (`Ssn`),
  KEY `Mgr_ssn` (`Mgr_ssn`),
  KEY `Send_num` (`Send_num`),
  KEY `Withdrawal_num` (`Withdrawal_num`),
  CONSTRAINT `user_ibfk_1` FOREIGN KEY (`Mgr_ssn`) REFERENCES `manager` (`Ssn`),
  CONSTRAINT `user_ibfk_2` FOREIGN KEY (`Send_num`) REFERENCES `account` (`Accountnumber`),
  CONSTRAINT `user_ibfk_3` FOREIGN KEY (`Withdrawal_num`) REFERENCES `account` (`Accountnumber`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES ('M','SEOUL','김인직','1998-02-08',0,NULL,NULL,NULL,NULL,NULL,'111111111','960710',NULL,NULL),('M','seoul','Mike','1997-08-02',1,NULL,NULL,NULL,NULL,NULL,'121212121','960710',NULL,NULL),('M','USA','john','1954-05-07',1,NULL,NULL,NULL,NULL,NULL,'131313131','950909',NULL,NULL),('F','감자마을','김남혁','1994-01-12',1,NULL,NULL,'2018-12-03',1000,'한승도','940112999','950909','9999999999',NULL),('M','korea','injik','1994-03-04',0,NULL,NULL,NULL,NULL,NULL,'950606121','960710',NULL,NULL),('M','한남','한승도','1995-12-12',1,'2018-12-03',1000,'2018-12-03',90000,'한승도','951212123','961019',NULL,'7777777777'),('M','광주먹마을','과고ㄱ이건명','1997-01-22',1,NULL,NULL,NULL,NULL,NULL,'970122333','960710',NULL,NULL);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-12-04 13:19:09
