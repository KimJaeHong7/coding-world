
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.Scanner;

public class Bank {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s;
		ArrayList<BankDTO> list = new ArrayList<BankDTO>();
		ArrayList<UserDTO> list1 = new ArrayList<UserDTO>();
		ArrayList<AccountDTO> list2 = new ArrayList<AccountDTO>();
		ArrayList<checkDTO> list3 = new ArrayList<checkDTO>();
		String menu = null;
		s = new Scanner(System.in);
		
		do{
			System.out.println("--- �޴��Դϴ�. ---");
			System.out.println("1. �����ڸ��");
			System.out.println("2. ����ڸ��");
			System.out.println("3. ����� ���");
			System.out.println("4. ����");
			System.out.print("�޴��� �Է��ϼ��� => ");
			menu = s.nextLine();
			BankService service = new BankService();
			if(menu.equals("1"))
			{
				String menu1="NULL";
				do {
				System.out.println("--- ������ ����Դϴ�. ---");
				System.out.println("1. �����ڼ���");
				System.out.println("2. �����ڵ��");
				System.out.println("3. ����");
				System.out.print("�޴��� �Է��ϼ��� => ");
				menu1 = s.nextLine();
				
				if (menu1.equals("1")) {
					BankDTO dto = new BankDTO();
					//BankService service = new BankService();
					list = service.adminList();
					for(int i = 0; i<list.size();i++)
					System.out.println(list.get(i).getName());
					System.out.print("���ϴ� ������ Ssn�� �Է��ϼ��� => ");
					String menu2 = s.nextLine();
					System.out.println("--- ������ ����Դϴ�. ---");
					System.out.println("1. ����� ��ȸ");
					System.out.println("2. ����");
					System.out.print("�޴��� �����ϼ��� => ");
					String menu22 = s.nextLine();
					if(menu22.equals("1")) {
						list1 = service.UserList(menu2);
						System.out.println("   |�̸� |"+"����|"+"���� ��|"+"Ssn|");
						for(int i = 0; i<list1.size();i++) {
							System.out.println(i+1+". " +list1.get(i).getName()+", "+list1.get(i).getSex()+", "+list1.get(i).getAccount_count()+", "+list1.get(i).getSsn());
						}
					}	
					else if(menu22.equals("2")) {
						continue;
					}
					
				}
				else if(menu1.equals("2")) {
					System.out.println("������ ������ �Է��ϼ���-->");
					System.out.print("���� : ");
					String menu23 =s.nextLine();
					System.out.print("���� : ");
					String menu26 = s.nextLine();
					System.out.print("�̸� : ");
					String menu27 = s.nextLine();
					System.out.print("�ּ� : ");
					String Address = s.nextLine();
					System.out.print("������ȣ : ");
					String menu28 = s.nextLine();
					System.out.print("���� : ");
					int menu24 = s.nextInt();
					s.nextLine();
					service.insertAdmin(menu23, menu24, Address, menu26, menu27, menu28);
				}
				else
					continue;
				}while(!(menu1.equals("3")));
			}
			else if (menu.equals("2"))
			{
				try {
				System.out.print("Ssn�� �Է��ϼ���=>");
				String ssn = s.nextLine();
				boolean ok = true;
				AccountDTO ac = new AccountDTO();
				UserDTO dto = new UserDTO();
				UserDTO dto1 = new UserDTO();
				dto = service.search_User(ssn);
				if(dto.getSsn() == null){
					continue;
				}
				else {
				System.out.println("�̸��� " + dto.getName() +" �Դϴ�! "+ "��  "+dto.getAccount_count()+"���� ���¸� ���� ���Դϴ�.");
				String menu3 = "NULL";
				System.out.println("--- ����� ����Դϴ�. ---");
				System.out.println("0. ���� ����");
				System.out.println("1. ���µ��");
				System.out.println("2. ���� ���� Ȯ��");
				System.out.println("3. ���� ��ü");
				System.out.println("4. ���");
				System.out.println("5. ����� ���� Ȯ��");
				System.out.println("6. check card ���");
				System.out.println("7. check card ����");
				System.out.println("8. ����");
				System.out.print("�޴��� �Է��ϼ��� => ");
				menu3 = s.nextLine();
				if(menu3.equals("0")) {
					System.out.print("������ ���¹�ȣ�� �Է��ϼ���=> ");
					String menu0 = s.nextLine();
					service.del_Account(menu0);
				}
				else if (menu3.equals("1")) {
					System.out.print("���¹�ȣ�� �Է��ϼ��� => ");
					String menu4 = s.nextLine();
					list2=service.AccountList();
					for(int i=0;i<list2.size();i++) {
						if(list2.get(i).getAccountnumber().equals(menu4)==true) {
							ok=false;
							break;
						}
						else
							ok=true;
					}
					if(ok==true) {
					dto1=service.addAcount(menu4, ssn);
					System.out.println("���� ����� ���������� �Ϸ� �Ǿ����ϴ�.");
					}
					else {
						System.out.println("�̹� �����ϴ� ���� ��ȣ �Դϴ�.");
						continue;
				}
				}
				else if(menu3.equals("2")) {
					System.out.print("���¹�ȣ�� �Է��ϼ��� => ");
					String menu5 = s.nextLine();
					ac = service.searchAccount(menu5);
					System.out.println("���¹�ȣ: "+ac.getAccountnumber()+" �ܰ�: "+ac.getMoney()+" ���� ����: "+ac.getMakedate()+" �Դϴ�.");
				}
				else if(menu3.equals("3")) {
					System.out.print("�ڽ��� ���¹�ȣ�� �Է��ϼ���=>");
					String menu32 = s.nextLine();
					System.out.print("�Ա��� ���¹�ȣ�� �Է��ϼ���=>");
					String menu30 = s.nextLine();
					System.out.print("���ϴ� �ݾ��� �Է����ּ���=>");
					int menu31 = s.nextInt();
					s.nextLine();
					service.Sending(menu32, menu31, menu30);
				}
				else if(menu3.equals("4")) {
					System.out.print("����� ���ϴ� ���¸� �Է��ϼ���=>");
					String menu42 = s.nextLine();
					System.out.print("����Ͻñ� ���ϴ� �ݾ��� �Է��ϼ���=>");
					int menu43 = s.nextInt();
					s.nextLine();
					service.Out(menu42, menu43);
				}
				else if (menu3.equals("5")) {
					service.printuse(ssn);
				}
				else if(menu3.equals("6")) {
					System.out.print("check ī�� ������ ����ϴ� ���¹�ȣ: ");
					String Accountnumber = s.nextLine();
					System.out.print("check ī�� ��ȣ: ");
					String num = s.nextLine();
					list3=service.cardList();
					for(int i=0;i<list3.size();i++) {
						if(list3.get(i).getCardnumber().equals(num)==true) {
							ok=false;
							break;
						}
						else
							ok=true;
					}
					if(ok==true)
						service.addCard(num, ssn, Accountnumber);
					else {
						System.out.println("�̹� �����ϴ� ��ȣ �Դϴ�.");
					}
				}
				else if(menu3.equals("7")) {
					System.out.print("���� �� ī�� ��ȣ�� �Է��ϼ���=>");
					String number = s.nextLine();
					service.del_Card(number);
				}
				}
				}
				catch(Exception e){
					//���� ������ ����� ���� ���
					System.out.println(e);
				}
			}
			else if(menu.equals("3"))
			{
					System.out.println("����� ������ �Է��ϼ���-->");
					System.out.print("���� : ");
					String menu01 =s.nextLine();
					System.out.print("�ּ� : ");
					String menu02 = s.nextLine();
					System.out.print("�̸� : ");
					String menu03 = s.nextLine();
					System.out.print("���� : ");
					String menu04 = s.nextLine();
					System.out.print("������ ������ȣ : ");
					String menu05 = s.nextLine();
					System.out.print("Ssn : ");
					String menu06 = s.nextLine();
					service.insertUser(menu01, menu02, menu03, menu04, menu05, menu06);
			}
			

			
		}while(!menu.equals("4"));
		System.out.println("���α׷� ����");
			
	}

}
class BankDTO {
	
	String Sex;
	double Salary;
	String Address;
	String BirthDate;
	String Name;
	String Ssn;
	public String getSex() {
		return Sex;
	}
	public void setSex(String sex) {
		Sex = sex;
	}
	public double getSalary() {
		return Salary;
	}
	public void setSalary(double salary) {
		Salary = salary;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public String getBirthDate() {
		return BirthDate;
	}
	public void setBirthDate(String birthDate) {
		BirthDate = birthDate;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getSsn() {
		return Ssn;
	}
	public void setSsn(String ssn) {
		Ssn = ssn;
	}
}
class UserDTO {
	String Sex;
	String Address;
	String Name;
	String Birthdate;
	int Account_count;
	String Withdrawal_Date;
	int Withdrawal_money;
	int Bank_money;
	String Send_Date;
	int Send_money;
	String Send_who;
	String Ssn;
	String Mgr_ssn;
	String Send_num;
	String Withdrawal_num;
	public String getWithdrawal_num() {
		return Withdrawal_num;
	}
	public void setWithdrawal_num(String withdrawal_num) {
		Withdrawal_num = withdrawal_num;
	}
	public String getSex() {
		return Sex;
	}
	public void setSex(String sex) {
		Sex = sex;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getBirthdate() {
		return Birthdate;
	}
	public void setBirthdate(String birthdate) {
		Birthdate = birthdate;
	}
	public int getAccount_count() {
		return Account_count;
	}
	public void setAccount_count(int account_count) {
		Account_count = account_count;
	}
	public String getWithdrawal_Date() {
		return Withdrawal_Date;
	}
	public void setWithdrawal_Date(String withdrawal_Date) {
		Withdrawal_Date = withdrawal_Date;
	}
	public int getWithdrawal_money() {
		return Withdrawal_money;
	}
	public void setWithdrawal_money(int withdrawal_money) {
		Withdrawal_money = withdrawal_money;
	}
	public int getBank_money() {
		return Bank_money;
	}
	public void setBank_money(int bank_money) {
		Bank_money = bank_money;
	}
	public String getSend_Date() {
		return Send_Date;
	}
	public void setSend_Date(String send_Date) {
		Send_Date = send_Date;
	}
	public int getSend_money() {
		return Send_money;
	}
	public void setSend_money(int send_money) {
		Send_money = send_money;
	}
	public String getSend_who() {
		return Send_who;
	}
	public void setSend_who(String send_who) {
		Send_who = send_who;
	}
	public String getSsn() {
		return Ssn;
	}
	public void setSsn(String ssn) {
		Ssn = ssn;
	}
	public String getMgr_ssn() {
		return Mgr_ssn;
	}
	public void setMgr_ssn(String mgr_ssn) {
		Mgr_ssn = mgr_ssn;
	}
	public String getSend_num() {
		return Send_num;
	}
	public void setSend_num(String send_num) {
		Send_num = send_num;
	}
	
}
class checkDTO {
	int money;
	String validity;
	String Accountnumber;
	String Usr_ssn;
	String cardnumber;
	public int getMoney() {
		return money;
	}
	public void setMoney(int money) {
		this.money = money;
	}
	public String getValidity() {
		return validity;
	}
	public void setValidity(String validity) {
		this.validity = validity;
	}
	public String getAccountnumber() {
		return Accountnumber;
	}
	public void setAccountnumber(String accountnumber) {
		Accountnumber = accountnumber;
	}
	public String getUsr_ssn() {
		return Usr_ssn;
	}
	public void setUsr_ssn(String usr_ssn) {
		Usr_ssn = usr_ssn;
	}
	public String getCardnumber() {
		return cardnumber;
	}
	public void setCardnumber(String cardnumber) {
		this.cardnumber = cardnumber;
	}
	
}
class AccountDTO {
	int money;
	String Makedate;
	String Accountnumber;
	String Usr_ssn;
	public int getMoney() {
		return money;
	}
	public void setMoney(int money) {
		this.money = money;
	}
	public String getMakedate() {
		return Makedate;
	}
	public void setMakedate(String makedate) {
		Makedate = makedate;
	}
	public String getAccountnumber() {
		return Accountnumber;
	}
	public void setAccountnumber(String accountnumber) {
		Accountnumber = accountnumber;
	}
	public String getUsr_ssn() {
		return Usr_ssn;
	}
	public void setUsr_ssn(String usr_ssn) {
		Usr_ssn = usr_ssn;
	}
}

class BankService {

	
	public void insertAdmin(String Sex, int salary,String Address, String BirthDate, String Name, String Ssn) {
		BankDAO dao = new BankDAO();
		dao.insertAdmin(Sex,salary,Address, BirthDate,Name,Ssn);
		}
	public void insertUser(String Sex,String Address,String Name, String BirthDate,String Mgr_ssn, String Ssn) {
		BankDAO dao = new BankDAO();
		dao.insertUser(Sex,Address,Name,BirthDate,Mgr_ssn,Ssn);
		}
	
	public ArrayList<BankDTO> adminList() {
		ArrayList<BankDTO> list = new ArrayList<BankDTO>();
		BankDAO dao = new BankDAO();
		list = dao.getAdminList();
		
		
		return list;
	}
	public UserDTO search_User(String ssn) {
		UserDTO usr = new UserDTO();
		BankDAO dao = new BankDAO();
		usr = dao.getUser(ssn);
		
		
		return usr;
	}
	
	public UserDTO addAcount(String accountNumber, String userSsn) {
		BankDAO dao = new BankDAO();
		UserDTO usr = new UserDTO();
		usr = dao.addAcount(accountNumber, userSsn);
		
		
		return usr;
	}
	public ArrayList<UserDTO> UserList(String Ssn) {
		ArrayList<UserDTO> list = new ArrayList<UserDTO>();
		BankDAO dao = new BankDAO();
		list = dao.getUserList(Ssn);
		
		
		return list;
	}
	public ArrayList<AccountDTO> AccountList() {
		ArrayList<AccountDTO> list = new ArrayList<AccountDTO>();
		BankDAO dao = new BankDAO();
		list = dao.getAccountList();
		
		
		return list;
	}
	public AccountDTO searchAccount(String Accountnumber) {
		BankDAO dao = new BankDAO();
		AccountDTO ac = new AccountDTO();
		ac=dao.searchAccount(Accountnumber);
		return ac;
	}
	public void Sending(String from, int money, String Accountnumber) {
		BankDAO dao = new BankDAO();
		dao.Sending(from,money,Accountnumber);
		}
	public void Out(String Accountnumber, int money) {
		BankDAO dao = new BankDAO();
		dao.Out(Accountnumber,money);
		}
	public void printuse(String ssn) {
		BankDAO dao = new BankDAO();
		dao.printuse(ssn);
		}
	public checkDTO addCard(String cardNumber, String ssn,String Accountnumber) {
		BankDAO dao = new BankDAO();
		checkDTO usr = new checkDTO();
		usr = dao.addCard(cardNumber,ssn,Accountnumber);
		
		
		return usr;
	}
	public ArrayList<checkDTO> cardList() {
		ArrayList<checkDTO> list = new ArrayList<checkDTO>();
		BankDAO dao = new BankDAO();
		list = dao.getcardList();
		
		
		return list;
	}
	public void del_Account(String number) {
		BankDAO dao = new BankDAO();
		dao.del_Account(number);
	}
	public void del_Card(String number) {
		BankDAO dao = new BankDAO();
		dao.del_Card(number);
	}

}
class BankDAO {

	public ArrayList<BankDTO> getAdminList() {
		ArrayList<BankDTO> list = new ArrayList<BankDTO>();
		try{
			Class.forName("org.mariadb.jdbc.Driver");
			
			String url = "jdbc:mariadb://localhost:3306/bank";
			String id = "root";
			String pw = "kjh9607";
			Connection con = DriverManager.getConnection(url,id,pw);	
			
			String sql = "select Name from manager";
			PreparedStatement pstmt = con.prepareStatement(sql);
			
			pstmt = con.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				BankDTO dto = new BankDTO();
			    dto.setName(rs.getString("Name"));
			    list.add(dto);
			}
			rs.close();
			pstmt.close();
			con.close();
			
			
		}catch(Exception e){
			System.out.println(e);
		}
		
		
		return list;
	}
	public UserDTO getUser(String ssn) {
		UserDTO usr = new UserDTO();
		try{
			Class.forName("org.mariadb.jdbc.Driver");
			
			String url = "jdbc:mariadb://localhost:3306/bank";
			String id = "root";
			String pw = "kjh9607";
			Connection con = DriverManager.getConnection(url,id,pw);	
			
			String sql = "select Name,Ssn,Account_count from user where Ssn = ?";
			PreparedStatement pstmt = con.prepareStatement(sql);
			
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, ssn);
			ResultSet rs = pstmt.executeQuery();
			rs.next();
			usr.setName(rs.getString("Name"));
			usr.setSsn(rs.getString("Ssn"));
			usr.setAccount_count(rs.getInt("Account_count"));

			rs.close();
			pstmt.close();
			con.close();
			
			
		}catch(Exception e){
			System.out.println(e);
		}
		
		
		return usr;
	}
	
	public UserDTO addAcount(String accountNumber, String userSsn) {
		UserDTO usr = new UserDTO();
		SimpleDateFormat mSimpleDateFormat = new SimpleDateFormat ( "yyyy-MM-dd", Locale.KOREA );
		Date currentTime = new Date();
		String mTime = mSimpleDateFormat.format ( currentTime );
		try{
			Class.forName("org.mariadb.jdbc.Driver");
			
			String url = "jdbc:mariadb://localhost:3306/bank";
			String id = "root";
			String pw = "kjh9607";
			Connection con = DriverManager.getConnection(url,id,pw);	
			String sql1 = "select Account_count from user where Ssn=?";
			PreparedStatement pstmt1 = con.prepareStatement(sql1);
			pstmt1 = con.prepareStatement(sql1);
			pstmt1.setString(1, userSsn);
			ResultSet rs1 = pstmt1.executeQuery();
			rs1.next();
			usr.setAccount_count(rs1.getInt("Account_count"));
			int num = usr.getAccount_count();
			if(num<10) {
			String sql = "insert into account values (?,?,?,?)";
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, 0);
			pstmt.setString(2, mTime);
			pstmt.setString(3,accountNumber);
			pstmt.setString(4, userSsn);
			ResultSet rs = pstmt.executeQuery();
			rs.next();
			String sql2 = "update user set Account_count=? where Ssn=?";
			PreparedStatement pstmt2 = con.prepareStatement(sql2);
			pstmt2 = con.prepareStatement(sql2);
			pstmt2.setInt(1, num+1);
			pstmt2.setString(2, userSsn);
			ResultSet rs2 = pstmt2.executeQuery();
			rs2.next();
			rs.close();
			pstmt.close();
			rs1.close();
			pstmt1.close();
			rs2.close();
			pstmt2.close();
			con.close();
			}
			else
			{
				System.out.println("TOO MANY");
			}
			
			
		}catch(Exception e){
			System.out.println(e);
		}
		
		
		return usr;
	}
	public ArrayList<UserDTO> getUserList(String ssn) {
		ArrayList<UserDTO> list = new ArrayList<UserDTO>();
		try{
			Class.forName("org.mariadb.jdbc.Driver");
			
			String url = "jdbc:mariadb://localhost:3306/bank";
			String id = "root";
			String pw = "kjh9607";
			Connection con = DriverManager.getConnection(url,id,pw);	
	
			String sql = "select Name, Sex, Account_count, Ssn from user  where Mgr_ssn=?";
			PreparedStatement pstmt = con.prepareStatement(sql);
			
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1,ssn);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				UserDTO dto = new UserDTO();
			    dto.setName(rs.getString("Name"));
			    dto.setSex(rs.getString("Sex"));
			    dto.setAccount_count(rs.getInt("Account_count"));
			    dto.setSsn(rs.getString("Ssn"));
			    list.add(dto);
			}
			rs.close();
			pstmt.close();
			con.close();
			
			
		}catch(Exception e){
			System.out.println(e);
		}
		
		
		return list;
	}
	public ArrayList<AccountDTO> getAccountList() {
		ArrayList<AccountDTO> list = new ArrayList<AccountDTO>();
		try{
			Class.forName("org.mariadb.jdbc.Driver");
			
			String url = "jdbc:mariadb://localhost:3306/bank";
			String id = "root";
			String pw = "kjh9607";
			Connection con = DriverManager.getConnection(url,id,pw);	
			
			String sql = "select Accountnumber from account";
			PreparedStatement pstmt = con.prepareStatement(sql);
			
			pstmt = con.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				AccountDTO dto = new AccountDTO();
			    dto.setAccountnumber("Accountnumber");
			    list.add(dto);
			}
			rs.close();
			pstmt.close();
			con.close();
			
			
		}catch(Exception e){
			System.out.println(e);
		}
		
		
		return list;
	}
	public void insertAdmin(String Sex, int salary, String Address, String BirthDate, String Name, String Ssn) {
		try{
			Class.forName("org.mariadb.jdbc.Driver");
			
			String url = "jdbc:mariadb://localhost:3306/bank";
			String id = "root";
			String pw = "kjh9607";
			Connection con = DriverManager.getConnection(url,id,pw);	
			String sql = "insert into manager values (?,?,?,?,?,?)";
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, Sex);
			pstmt.setInt(2, salary);
			pstmt.setString(3, Address);
			pstmt.setString(4, BirthDate);
			pstmt.setString(5, Name);
			pstmt.setString(6, Ssn);
			ResultSet rs = pstmt.executeQuery();
			System.out.println("����� �Ϸ� �Ǿ����ϴ�!");
			rs.next();
			rs.close();
			pstmt.close();
			
		}catch(Exception e){
			System.out.println(e);
		}
	}
	public void insertUser(String Sex,String Address,String Name, String BirthDate,String Mgr_ssn, String Ssn) {
		try{
			Class.forName("org.mariadb.jdbc.Driver");
			
			String url = "jdbc:mariadb://localhost:3306/bank";
			String id = "root";
			String pw = "kjh9607";
			Connection con = DriverManager.getConnection(url,id,pw);	
			String sql = "insert into user values (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, Sex);
			pstmt.setString(2, Address);
			pstmt.setString(3, Name);
			pstmt.setString(4, BirthDate);
			pstmt.setInt(5, 0);
			pstmt.setNull(6, Types.DATE);
			pstmt.setNull(7, Types.INTEGER);
			pstmt.setNull(8, Types.DATE);
			pstmt.setNull(9, Types.INTEGER);
			pstmt.setNull(10, Types.VARCHAR);
			pstmt.setString(11, Ssn);
			pstmt.setString(12, Mgr_ssn);
			pstmt.setNull(13, Types.CHAR);
			pstmt.setNull(14, Types.CHAR);
			ResultSet rs = pstmt.executeQuery();
			System.out.println("����� �Ϸ� �Ǿ����ϴ�!");
			rs.next();
			rs.close();
			pstmt.close();
			
			
		}catch(Exception e){
			System.out.println(e);
		}
	}
	public AccountDTO searchAccount(String Accountnumber) {
		AccountDTO usr = new AccountDTO();
		try{
			Class.forName("org.mariadb.jdbc.Driver");
			
			String url = "jdbc:mariadb://localhost:3306/bank";
			String id = "root";
			String pw = "kjh9607";
			Connection con = DriverManager.getConnection(url,id,pw);	
			
			String sql = "select * from account where Accountnumber = ?";
			PreparedStatement pstmt = con.prepareStatement(sql);
			
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, Accountnumber);
			ResultSet rs = pstmt.executeQuery();
			rs.next();
			usr.setMoney(rs.getInt("money"));
			usr.setMakedate(rs.getString("Makedate"));
			usr.setAccountnumber(rs.getString("Accountnumber"));
			
			rs.close();
			pstmt.close();
			con.close();
			
			
		}catch(Exception e){
			System.out.println(e);
		}
		
		
		return usr;
	}
	public void Sending(String from, int money,String Accountnumber) {
		SimpleDateFormat mSimpleDateFormat = new SimpleDateFormat ( "yyyy-MM-dd", Locale.KOREA );
		Date currentTime = new Date();
		String mTime = mSimpleDateFormat.format ( currentTime );
		try{
			AccountDTO ac = new AccountDTO();
			Class.forName("org.mariadb.jdbc.Driver");
			
			String url = "jdbc:mariadb://localhost:3306/bank";
			String id = "root";
			String pw = "kjh9607";
			Connection con = DriverManager.getConnection(url,id,pw);	
			String sql = "select money from account where Accountnumber=?";
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, from);
			ResultSet rs = pstmt.executeQuery();
			rs.next();
			ac.setMoney(rs.getInt("money"));
			if(from.equals(Accountnumber)) {
				String sql1 = "update account set money=? where Accountnumber=?";
				PreparedStatement pstmt1 = con.prepareStatement(sql1);
				pstmt1 = con.prepareStatement(sql1);
				pstmt1.setInt(1, ac.getMoney()+money);
				pstmt1.setString(2, Accountnumber);
				ResultSet rs1 = pstmt1.executeQuery();//��
				String sq = "update check_card set money=money+? where Accountnumber=?";
				PreparedStatement pstm = con.prepareStatement(sq);
				pstm = con.prepareStatement(sq);
				pstm.setInt(1, money);
				pstm.setString(2, Accountnumber);
				ResultSet rs3 = pstm.executeQuery();
				String q = "select Usr_ssn from account where Accountnumber=?";
				PreparedStatement p = con.prepareStatement(q);
				p = con.prepareStatement(q);
				p.setString(1, Accountnumber);
				ResultSet result = p.executeQuery();
				result.next();
				String usr = result.getString("Usr_ssn");
				String q1 = "select Name from user where Ssn = ?";
				PreparedStatement p1 = con.prepareStatement(q1);
				p1 = con.prepareStatement(q1);
				p1.setString(1, usr);
				ResultSet re = p1.executeQuery();
				re.next();
				String s = "update user set Send_Date=?, Send_money=?, Send_who =? where Ssn=?";
				PreparedStatement a = con.prepareStatement(s);
				a = con.prepareStatement(s);
				a.setString(1, mTime);
				a.setInt(2, money);
				a.setString(3, re.getString("Name"));
				a.setString(4, usr);
				System.out.print("���� �ܰ��� "+money+"����");
				System.out.println("�Ա� �Ϸ�Ǿ����ϴ�!");
				ResultSet r = a.executeQuery();
				rs1.close();
				pstmt1.close();
				p.close();
				p1.close();
				re.close();
				a.close();
				r.close();
				pstm.close();
				rs3.close();
			}
			else {
				if(ac.getMoney()>money) {
				String sql1 = "update account set money=money+? where Accountnumber=?";
				PreparedStatement pstmt1 = con.prepareStatement(sql1);
				pstmt1 = con.prepareStatement(sql1);
				pstmt1.setInt(1, money);
				pstmt1.setString(2, Accountnumber);
				ResultSet rs1 = pstmt1.executeQuery();
				String sq = "update check_card set money=money+? where Accountnumber=?";
				PreparedStatement pstm = con.prepareStatement(sq);
				pstm = con.prepareStatement(sq);
				pstm.setInt(1, money);
				pstm.setString(2, Accountnumber);
				ResultSet rs3 = pstm.executeQuery();
				String sql2 = "update account set money=money-? where Accountnumber=?";
				PreparedStatement pstmt2 = con.prepareStatement(sql2);
				pstmt2 = con.prepareStatement(sql2);
				pstmt2.setInt(1, money);
				pstmt2.setString(2, from);
				ResultSet rs2 = pstmt2.executeQuery();
				String sq1 = "update check_card set money=money-? where Accountnumber=?";
				PreparedStatement pstm1 = con.prepareStatement(sq1);
				pstm1 = con.prepareStatement(sq1);
				pstm1.setInt(1, money);
				pstm1.setString(2, from);
				ResultSet rs4 = pstm1.executeQuery();
				String q = "select Usr_ssn from account where Accountnumber=?";//���� ��� ssn
				PreparedStatement p = con.prepareStatement(q);
				p = con.prepareStatement(q);
				p.setString(1, Accountnumber);
				ResultSet result = p.executeQuery();
				result.next();
				String usr = result.getString("Usr_ssn");
				String qe = "select Usr_ssn from account where Accountnumber=?";//�ڱ� �ڽ�
				PreparedStatement pq = con.prepareStatement(qe);
				pq = con.prepareStatement(qe);
				pq.setString(1, from);
				ResultSet result1 = pq.executeQuery();
				result1.next();
				String usr1 = result1.getString("Usr_ssn");
				String q1 = "select Name from user where Ssn = ?";
				PreparedStatement p1 = con.prepareStatement(q1);
				p1 = con.prepareStatement(q1);
				p1.setString(1, usr);
				ResultSet re = p1.executeQuery();
				re.next();
				String q2 = "select Name from user where Ssn = ?";
				PreparedStatement p2 = con.prepareStatement(q2);
				p2 = con.prepareStatement(q2);
				p2.setString(1, usr1);
				ResultSet re1 = p2.executeQuery();
				re1.next();
				String s = "update user set Send_Date=?, Send_money=?, Send_who =?,Send_num=? where Ssn=?";
				PreparedStatement a = con.prepareStatement(s);
				a = con.prepareStatement(s);
				a.setString(1, mTime);
				a.setInt(2, money);
				a.setString(3, re1.getString("Name"));
				a.setString(4, from);
				a.setString(5, usr);
				ResultSet r = a.executeQuery();
				String s1 = "update user set Withdrawal_Date=?, Withdrawal_money=?, Withdrawal_num=? where Ssn=?";
				PreparedStatement a3 = con.prepareStatement(s1);
				a3 = con.prepareStatement(s1);
				a3.setString(1, mTime);
				a3.setInt(2, money);
				a3.setString(3, Accountnumber);
				a3.setString(4, usr1);
				ResultSet r4 = a3.executeQuery();
				rs1.close();
				pstmt1.close();
				p.close();
				p1.close();
				p2.close();
				re1.close();
				re.close();
				a.close();
				r.close();
				pq.close();
				result1.close();
				result.close();
				pstm1.close();
				pstm.close();
				rs3.close();
				rs4.close();
				a3.close();
				r4.close();
				System.out.println("�Ա��� �Ϸ�Ǿ����ϴ�!");
			}
			else
					System.out.println("�ܾ׺���");
			rs.close();
			pstmt.close();
			}
			
		}catch(Exception e){
			System.out.println(e);
		}
	}
	
	public void Out(String Accountnumber, int money) {
		SimpleDateFormat mSimpleDateFormat = new SimpleDateFormat ( "yyyy-MM-dd", Locale.KOREA );
		Date currentTime = new Date();
		String mTime = mSimpleDateFormat.format ( currentTime );
		try{
			AccountDTO ac = new AccountDTO();
			Class.forName("org.mariadb.jdbc.Driver");
			
			String url = "jdbc:mariadb://localhost:3306/bank";
			String id = "root";
			String pw = "kjh9607";
			Connection con = DriverManager.getConnection(url,id,pw);	
			String sql = "select money from account where Accountnumber=?";
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, Accountnumber);
			ResultSet rs = pstmt.executeQuery();
			rs.next();
			ac.setMoney(rs.getInt("money"));
			if(ac.getMoney()>money) {
				String sql1 = "update account set money=money-? where Accountnumber=?";
				PreparedStatement pstmt1 = con.prepareStatement(sql1);
				pstmt1 = con.prepareStatement(sql1);
				pstmt1.setInt(1, money);
				pstmt1.setString(2, Accountnumber);
				ResultSet rs1 = pstmt1.executeQuery();//��
				String q = "select Usr_ssn from account where Accountnumber=?";
				PreparedStatement p = con.prepareStatement(q);
				p = con.prepareStatement(q);
				p.setString(1, Accountnumber);
				ResultSet result = p.executeQuery();
				result.next();
				String usr = result.getString("Usr_ssn");
				String q1 = "select Name from user where Ssn = ?";
				PreparedStatement p1 = con.prepareStatement(q1);
				p1 = con.prepareStatement(q1);
				p1.setString(1, usr);
				ResultSet re = p1.executeQuery();
				re.next();
				String s = "update user set Withdrawal_Date=?, Withdrawal_money=?, Withdrawal_num=? where Ssn=?";
				PreparedStatement a = con.prepareStatement(s);
				a = con.prepareStatement(s);
				a.setString(1, mTime);
				a.setInt(2, money);
				a.setString(3, Accountnumber);
				a.setString(4, usr);
				ResultSet r = a.executeQuery();
				String sql2 = "update check_card set money=money-? where Accountnumber=?";
				PreparedStatement pstmt0 = con.prepareStatement(sql2);
				pstmt0 = con.prepareStatement(sql2);
				pstmt0.setInt(1, money);
				pstmt0.setString(2, Accountnumber);
				ResultSet rs9 = pstmt1.executeQuery();
				rs1.close();
				pstmt1.close();
				System.out.println("���� �ܰ��� "+(ac.getMoney()-money)+"�� �Դϴ�.");
			System.out.println("����� �Ϸ�Ǿ����ϴ�!");
			rs1.close();
			pstmt1.close();
			p.close();
			p1.close();
			re.close();
			a.close();
			r.close();
			rs9.close();
			pstmt0.close();
			}
			else {
				System.out.println("�ܾ� ����!");
			}
		}catch(Exception e){
			System.out.println(e);
		}
	}
	public void printuse(String ssn) {
		UserDTO dto = new UserDTO();
		try{
			Class.forName("org.mariadb.jdbc.Driver");
			
			String url = "jdbc:mariadb://localhost:3306/bank";
			String id = "root";
			String pw = "kjh9607";
			Connection con = DriverManager.getConnection(url,id,pw);	
			
			String sql = "select Withdrawal_Date,Withdrawal_money,Send_who,Send_money,Send_Date,Withdrawal_num from user where Ssn=?";
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, ssn);
			ResultSet rs = pstmt.executeQuery();
			rs.next();
			dto.setWithdrawal_num(rs.getString("Withdrawal_num"));
			dto.setWithdrawal_Date(rs.getString("Withdrawal_Date"));
			dto.setSend_Date(rs.getString("Send_Date"));
			dto.setSend_who(rs.getString("Send_who"));
			dto.setSend_money(rs.getInt("Send_money"));
			dto.setWithdrawal_money(rs.getInt("Withdrawal_money"));
			String sql1 = "select Usr_ssn from account where Accountnumber=?";
			PreparedStatement pstmt1 = con.prepareStatement(sql1);
			pstmt1 = con.prepareStatement(sql1);
			pstmt1.setString(1, dto.getWithdrawal_num());
			ResultSet rs1 = pstmt1.executeQuery();
			rs1.next();
			String sql11 = "select Name from user where Ssn=?";
			PreparedStatement pstmt11 = con.prepareStatement(sql11);
			pstmt11 = con.prepareStatement(sql11);
			pstmt11.setString(1, rs1.getString("Usr_ssn"));
			ResultSet rs11 = pstmt11.executeQuery();
			rs11.next();
			
			System.out.println("������ ��� ��¥: "+dto.getWithdrawal_Date());
			System.out.println("��� �ݾ�: "+dto.getWithdrawal_money());
			System.out.println("����� ���: "+rs11.getString("Name"));
			System.out.println("������ �Ա�(��ü)���� ��¥: "+dto.getSend_Date());
			System.out.println("������ �Ա�(��ü)���� �ݾ�: "+dto.getSend_money());
			System.out.println("�Ա����� ���: "+dto.getSend_who());
			rs.close();
			pstmt.close();
			con.close();
			
			
		}catch(Exception e){
			System.out.println(e);
		}
		
	}
	public checkDTO addCard(String cardNumber, String userSsn, String Accountnumber) {
		checkDTO usr = new checkDTO();
		AccountDTO ac = new AccountDTO();
		SimpleDateFormat mSimpleDateFormat = new SimpleDateFormat ( "yyyy-MM-dd", Locale.KOREA );
		Date currentTime = new Date();
		 Calendar cal = Calendar.getInstance();
	        cal.setTime(currentTime);
	        cal.add(Calendar.YEAR, 5);
		String mTime = mSimpleDateFormat.format ( cal.getTime() );
		try{
			Class.forName("org.mariadb.jdbc.Driver");

			String url = "jdbc:mariadb://localhost:3306/bank";
			String id = "root";
			String pw = "kjh9607";
			Connection con = DriverManager.getConnection(url,id,pw);
			String q = "select money from account where Accountnumber=?";
			PreparedStatement p = con.prepareStatement(q);
			p = con.prepareStatement(q);
			p.setString(1, Accountnumber);
			ResultSet result = p.executeQuery();
			result.next();
			ac.setMoney(result.getInt("money"));
			String sql = "insert into check_card values (?,?,?,?,?)";
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, ac.getMoney());
			pstmt.setString(2, mTime);
			pstmt.setString(3,Accountnumber);
			pstmt.setString(4, userSsn);
			pstmt.setString(5, cardNumber);
			pstmt.executeUpdate();
			pstmt.close();
			con.close();
			
			
		}catch(Exception e){
			System.out.println(e);
		}
		
		
		return usr;
	}
	public ArrayList<checkDTO> getcardList() {
		ArrayList<checkDTO> list = new ArrayList<checkDTO>();
		try{
			Class.forName("org.mariadb.jdbc.Driver");

			String url = "jdbc:mariadb://localhost:3306/bank";
			String id = "root";
			String pw = "kjh9607";
			Connection con = DriverManager.getConnection(url,id,pw);	
			
			String sql = "select cardnumber from check_card";
			PreparedStatement pstmt = con.prepareStatement(sql);
			
			pstmt = con.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				checkDTO dto = new checkDTO();
			    dto.setCardnumber("cardnumber");
			    list.add(dto);
			}
			rs.close();
			pstmt.close();
			con.close();
			
			
		}catch(Exception e){
			System.out.println(e);
		}
		
		
		return list;
	}
	public void del_Account(String Accountnumber) {
		UserDTO usr = new UserDTO();
		int count=0;
		ArrayList<UserDTO> list = new ArrayList<UserDTO>();
		try{
			Class.forName("org.mariadb.jdbc.Driver");
			
			String url = "jdbc:mariadb://localhost:3306/bank";
			String id = "root";
			String pw = "kjh9607";
			Connection con = DriverManager.getConnection(url,id,pw);	
			String ssn_sq = "select Usr_ssn from account where Accountnumber=?";
			PreparedStatement ps = con.prepareStatement(ssn_sq);
			ps = con.prepareStatement(ssn_sq);
			ps.setString(1, Accountnumber);
			ResultSet r = ps.executeQuery();
			r.next();
			String n = "select Ssn from user where Withdrawal_num=?";
			PreparedStatement ps1 = con.prepareStatement(n);
			ps1 = con.prepareStatement(n);
			ps1.setString(1, Accountnumber);
			ResultSet m = ps1.executeQuery();
			String n1 = "select Ssn from user where Send_num=?";
			PreparedStatement psn1 = con.prepareStatement(n1);
			psn1 = con.prepareStatement(n);
			psn1.setString(1, Accountnumber);
			ResultSet mn = psn1.executeQuery();
			while(m.next()) {
				count++;
				String sql7 = "update user set Withdrawal_num=? where Ssn=?";
				PreparedStatement pstmt9 = con.prepareStatement(sql7);			
				pstmt9 = con.prepareStatement(sql7);
				pstmt9.setNull(1, Types.VARCHAR);
				pstmt9.setString(2, m.getString("Ssn"));
				ResultSet rs3 = pstmt9.executeQuery();
				rs3.next();
				String sql = "delete from account where Accountnumber = ?";
				PreparedStatement pstmt = con.prepareStatement(sql);			
				pstmt = con.prepareStatement(sql);
				pstmt.setString(1, Accountnumber);
				ResultSet rs = pstmt.executeQuery();
				rs.next();
				String sq = "delete from check_card where Accountnumber = ?";
				PreparedStatement pstmt2 = con.prepareStatement(sq);
				pstmt2 = con.prepareStatement(sq);
				pstmt2.setString(1, Accountnumber);
				ResultSet rs11 = pstmt.executeQuery();
				rs11.next();
				String up = "update user set Account_count=Account_count-? where Ssn=?";
				PreparedStatement u = con.prepareStatement(up);
				u = con.prepareStatement(up);
				u.setInt(1, 1);
				u.setString(2, r.getString("Usr_ssn"));
				ResultSet a = u.executeQuery();
				pstmt2.close();
				rs11.close();
				u.close();
				a.close();
				rs.close();
				pstmt.close();
				psn1.close();
				mn.close();
				ps1.close();
				m.close();
			}
			while(mn.next()) {
				count++;
				String sql7 = "update user set Send_num=? where Ssn=?";
				PreparedStatement pstmt9 = con.prepareStatement(sql7);			
				pstmt9 = con.prepareStatement(sql7);
				pstmt9.setNull(1, Types.VARCHAR);
				pstmt9.setString(2, mn.getString("Ssn"));
				ResultSet rs3 = pstmt9.executeQuery();
				rs3.next();
				String sql = "delete from account where Accountnumber = ?";
				PreparedStatement pstmt = con.prepareStatement(sql);			
				pstmt = con.prepareStatement(sql);
				pstmt.setString(1, Accountnumber);
				ResultSet rs = pstmt.executeQuery();
				rs.next();
				String sq = "delete from check_card where Accountnumber = ?";
				PreparedStatement pstmt2 = con.prepareStatement(sq);
				pstmt2 = con.prepareStatement(sq);
				pstmt2.setString(1, Accountnumber);
				ResultSet rs11 = pstmt2.executeQuery();
				rs11.next();
				String up = "update user set Account_count=Account_count-? where Ssn=?";
				PreparedStatement u = con.prepareStatement(up);
				u = con.prepareStatement(up);
				u.setInt(1, 1);
				u.setString(2, r.getString("Usr_ssn"));
				ResultSet a = u.executeQuery();
				pstmt2.close();
				rs11.close();
				u.close();
				a.close();
				rs.close();
				pstmt.close();
				psn1.close();
				mn.close();
				ps1.close();
				m.close();
			}
			if(count==0) {
				String sql = "delete from account where Accountnumber = ?";
				PreparedStatement pstmt = con.prepareStatement(sql);			
				pstmt = con.prepareStatement(sql);
				pstmt.setString(1, Accountnumber);
				ResultSet rs = pstmt.executeQuery();
				String sq = "delete from check_card where Accountnumber = ?";
				PreparedStatement pstmt2 = con.prepareStatement(sq);
				pstmt2 = con.prepareStatement(sq);
				pstmt2.setString(1, Accountnumber);
				ResultSet rs11 = pstmt.executeQuery();
				String up = "update user set Account_count=Account_count-? where Ssn=?";
				PreparedStatement u = con.prepareStatement(up);
				u = con.prepareStatement(up);
				u.setInt(1, 1);
				u.setString(2, r.getString("Usr_ssn"));
				ResultSet a = u.executeQuery();
				System.out.println("������ �Ϸ�Ǿ����ϴ�!");
				pstmt2.close();
				rs11.close();
				u.close();
				a.close();
				rs.close();
				pstmt.close();
			}
			ps.close();
			r.close();
			ps1.close();
			m.close();
			con.close();
		}catch(Exception e){
			System.out.println(e);
		}
	}
		public void del_Card(String cardnumber) {
			try{
				Class.forName("org.mariadb.jdbc.Driver");
				
				String url = "jdbc:mariadb://localhost:3306/bank";
				String id = "root";
				String pw = "kjh9607";
				Connection con = DriverManager.getConnection(url,id,pw);	
				String ssn_sq = "delete from check_card where cardnumber=?";
				PreparedStatement ps = con.prepareStatement(ssn_sq);
				ps = con.prepareStatement(ssn_sq);
				ps.setString(1, cardnumber);
				ResultSet r = ps.executeQuery();
				r.next();
				ps.close();
				r.close();
				con.close();
			}catch(Exception e){
				System.out.println(e);
			}
		}
	
}

